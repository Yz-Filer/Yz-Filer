#!/bin/bash
export GTK_THEME=Adwaita:dark
./yz3
