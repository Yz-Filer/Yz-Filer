#!/bin/bash
MAGICK=convert




$MAGICK - -resize 1440x960\> -normalize -colorspace gray -gaussian-blur 2.0x1.2 \
\( -size 1440x960 xc:#000000 +noise Gaussian -equalize -colorspace gray -equalize -normalize \) \
\( -clone 0 -edge 3 -threshold 50% \) \
\( -clone 2 -clone 1 -compose Darken -composite -transparent black \) \
\( -size 1440x960 xc:#002800 \) \
\( -clone 3 -clone 4 -compose Plus -composite \) \
-delete 0-4 \
-format png -quality 00 png:-
