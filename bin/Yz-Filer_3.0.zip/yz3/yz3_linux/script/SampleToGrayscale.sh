#!/bin/bash
MAGICK=convert

$MAGICK - -colorspace gray \
-format png -quality 00 png:-
