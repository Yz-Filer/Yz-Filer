#!/bin/bash
MAGICK=convert







$MAGICK  - -resize 200% -resize 1440x960\> -normalize -colorspace gray -gaussian-blur 2.0x1.2 \
\( -size 10x10 xc:white -fx '(i + j) % 10 == 0 || (i + j) % 9 == 0 ? 1 : 0' -write mpr:t1 \) \
\( -size 1440x960 tile:mpr:t1 \) \
\( -clone 0 -edge 2 -threshold 50% \) \
\( -clone 0 -threshold 66% \) \
\( -clone 0 -threshold 33% \) \
\( -clone 5 -clone 4 -compose MinusSrc -composite \) \
\( -clone 6 -clone 2 -compose CopyOpacity -composite \) \
\( -clone 4 -clone 7 -compose Lighten -composite \) \
\( -clone 8 -clone 3 -compose Lighten -composite \) \
-delete 0-8 \
-resize 50% \
-format png -quality 00 png:-
