#!/bin/bash


# ****************************************************
#     Fred's ImageMagick Scripts:PAINTEFFECT
# ****************************************************

MAGICK=convert

gammaval=1.2
blur=2
paintval=5
edgegain=2






$MAGICK - -resize 720x480\> -normalize -gaussian-blur 2.0x1.2 \
-gamma $gammaval -selective-blur 0x${blur}+20% -paint $paintval \
\( +clone -sharpen 0x2 -morphology edgein diamond:1 \
-evaluate multiply $edgegain -colorspace gray -negate \) \
-compose multiply -composite \
-format png -quality 00 png:-
