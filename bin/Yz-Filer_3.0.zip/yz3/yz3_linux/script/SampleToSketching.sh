#!/bin/bash

# ****************************************************
#     Fred's ImageMagick Scripts:SKETCHING + noise
# ****************************************************

MAGICK=convert

grayscaling="-modulate 100,0,100"
edge=4
colorizing=
detailing="-evaluate pow 7"
saturating=






$MAGICK - -resize 200% -resize 1440x960\> -normalize -gaussian-blur 2.0x1.2 \
\( -clone 0 -colorspace gray -evaluate set 0 +noise Impulse \) \
\( -clone 1 -brightness-contrast -80x0% -motion-blur 20x20+315 \) \
\( -clone 1 -brightness-contrast -90x0% -motion-blur 20x20+295 \) \
\( -clone 1 -brightness-contrast -90x0% -motion-blur 20x20+335 \) \
\( -clone 2 -clone 3 -compose Plus -composite \) \
\( -clone 5 -clone 4 -compose Plus -composite \) \
\( -clone 0 -clone 6 -compose Plus -composite \) \
-delete 0-6 \
\( -clone 0 $grayscaling \) \
\( -clone 1 -negate -statistic minimum ${edge}x${edge} $colorizing \) \
\( -clone 1 -clone 2 -compose color_dodge -composite $detailing \) \
-delete 1-2 +swap -compose screen -composite $saturating \
-resize 50% \
-format png -quality 00 png:-
