#!/bin/bash

# ****************************************************
#     Fred's ImageMagick Scripts:WATERCOLOR
# ****************************************************

MAGICK=convert

smoothing=
edge=5
mixing=50
contrast=
sproc=
cproc=





$MAGICK - -resize 720x480\> -normalize -gaussian-blur 2.0x1.2 $cproc $sproc \
\( -clone 0 -define convolve:scale='!' \
-define morphology:compose=Lighten \
-morphology Convolve 'Sobel:>' \
-negate -evaluate pow $edge \) \
\( -clone 0 -clone 1 -compose luminize -composite \) \
-delete 1 -define compose:args=$mixing -compose blend -composite \
-format png -quality 00 png:-

