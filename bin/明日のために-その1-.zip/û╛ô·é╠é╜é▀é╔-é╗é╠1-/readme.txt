まだ作成中のためファイル操作（ファイルコピーや削除など）は未実装ですが、
WindowsをLinuxの踏み台にして作業するために、ssh/scp対応の検証中です。

１、ssh/scp対応
  ・F7：Mode=SCPでssh/scpドライブを登録
    ※セキュリティ情報を保存したくない場合、アカウント名やパスワードは未入力でも可
      （パスワードだけ未入力も可）
      その場合、接続のたびに入力が必要です
      ※パスワードを入力した場合は、暗号化されてローカルに保存されます

  ・ファイルにカーソルがある状態で
    ・V：バイナリビューアで表示
    ・ENTER：テキストビューア/イメージビューア/メディアビューアで表示
    ・SHIFT+ENTER：テキストエディタで開く
    ・CTRL+ENTER：ファイルの関連付けで開く

  ・F3：ssh/scpドライブの場合、登録したSSHクライアントで現在DIRを表示

  ・X：ssh/scpドライブの場合、登録したSSHクライアントでコマンド実行

  LINUX上でスクリプトを作成して実行するくらいの作業は出来ると思います。
  セキュリティ上、suはサポートしてませんので、F3キーコマンドでログイン後に対応して下さい

  テキストエディタや「ファイルの関連付けで開く」で更新した場合、
  アプリケーションを閉じる時に、アップロードが実施されます。
  保存しただけで開きっぱなしのままではアップロードされません
  ※ファイルを保存した場合、バックアップファイルが作成されます
  ※ファイルの関連付けで開いた場合も同様
  ※元ファイルが更新された場合やエラーが発生した場合は、エディタが
    再起動しますので、編集後ファイルをローカルドライブに退避して下さい


２、その他の変更
  ・起動後にドライブレターが増えた（USBドライブが追加された）ら、新タブが開く
    増えたタブを閉じたら、USBイジェクト処理を行う
  
  ・CTRL+Tキーコマンドで新タブを開く場所は、現在のタブの隣。
    デフォルトで開くドライブは、現在のタブと同じ。
  
  ・ListViewのPanelを変更したので、もっさりが改善
  
  ・ListViewの横スクロール化（段組み）
  
  ・ListViewに表示されてるファイル情報の横幅は変更できない
    （Bindingすると固まるため）
  
  ・テキストビューアをAvalonEditへ変更
    もっさりが改善したので、ファイルサイズ制限を引き上げ
    Ward wrapができるようになった
    改行文字が変更できるようになった（「ワン」とか「ニャン」などの複数文字も可能。…しないか）
  
  ・バイナリビューアをBe.HexEditorへ変更
    もっさりが改善したので、ファイルサイズ制限を引き上げ
    右側に表示されてるテキストを無理やり文字コード指定する機能は実装されてない
    遡って（上方向へ）検索する機能は実装されてない
  
  ・メディアビューアのバグ修正
    カーソルキーでSEEK時に、処理が貯まる不具合を修正
  
  ・イメージビューアでカーソル移動がもっさりするようになった
  
  ・イメージビューアのSFTP/SCPで、ファイル保存できるようになった
    保存場所は、Windowsのピクチャフォルダ
  
  ・SCPシンボリックリンクとWINショートカットになんとなく対応
    ディレクトリ移動は出来ると思います。
    SCPのファイルは、開くときにリンク先を開くようになってると思います
    WINのファイルは、拡張子の関連付けで開けばWindowsが勝手に元ファイルを開くと思います
  
  ・ZIPドライブはランサムウェア誤検出とかあるし、とりあえず見合わせ
  
  ・ファイル操作とファイル操作以外の一部のコマンドもまだ実装してない物がある
  
  ・ファイル監視もまだ実装してないため、F5キーコマンドで更新して下さい
    ※SFTP/SCPドライブは、将来的にもファイル監視は実装しない予定です


３、設定ファイルのSSH関連設定例

  「%」で囲まれた変数が以下のように置き換わります。
	
	%IP%            :IPアドレス
	%PORT%          :ポート番号
	%USER%          :ユーザ名
	%PASS%          :パスワード
	%KEY_FILE%      :鍵ファイルフルパス
	%CURRENT%       :カレントディレクトリ
	%MACRO_FILE%    :マクロファイル
	%COMMAND%       :Xキーコマンド時に追加設定されるコマンド文字列
	%SSH_ADD_MACRO% :追加されたマクロ文字列全体


以下、各SSHクライアント用の設定例です。
※設定ファイルは、書式（「\」→「\\」、「改行」→「\n」、「"」→「\"」など）に従って記載して下さい
※SSH_ADD_MACROは、Xキーコマンド用です。「%SSH_ADD_MACRO%」部に挿入されます
  「%SSH_ADD_MACRO%」は、F3キーコマンドの場合「」(空文字)に置き換えられます
※SSH_MACROに記載した内容は、%MACRO_FILE%に出力されます
  SSH_CLIENT_ARG内で「%MACRO_FILE%」を指定して下さい
※Xキーコマンド内で入力したlsやgrepで色がつかない場合、以下のコマンドを試してみてください
  ls --color=auto
  grep --color=auto


・Open SSH(Windows10に入ってる物。デフォルト設定。パスワード情報は引き渡し出来ない)
  "SSH_CLIENT": "C:\\Windows\\System32\\OpenSSH\\ssh.exe",
  "SSH_CLIENT_ARG": "%USER%@%IP% -p %PORT% -t \" cd '%CURRENT%';/bin/bash --login %SSH_ADD_MACRO%\"",
  "SSH_MACRO": "",
  "SSH_ADD_MACRO": " -c \\\"%COMMAND%; /bin/bash\\\""

  Enterキーで閉じる場合
  "SSH_ADD_MACRO": " -c \\\"%COMMAND%; echo; read -p 'Press enter key...'\\\""


・Tera Term(自環境では、waitがきいてないっぽいので、pauseを追加。また、文字コード解釈がおかしくなることがある)
  "SSH_CLIENT": "C:\\TeraTerm\\ttermpro.exe",
  "SSH_CLIENT_ARG": "%IP% /ssh /auth=password /user=%USER% /passwd=%PASS% /P=%PORT% /M=\"%MACRO_FILE%\"",
  "SSH_MACRO": "pause 1 \n wait \"$\" \n sendln \"cd %CURRENT%\" \n %SSH_ADD_MACRO%",
  "SSH_ADD_MACRO": "sendln \"%COMMAND%\" \n"

  Enterキーで閉じる場合
  "SSH_ADD_MACRO": "sendln \" %COMMAND%; echo; read -p 'Press enter key...'; exit \" \n"


・Putty
  "SSH_CLIENT": "C:\\Putty\\putty.exe",
  "SSH_CLIENT_ARG": "-ssh %IP% -P %PORT% -l %USER% -pw %PASS% -t -m \"%MACRO_FILE%\"",
  "SSH_MACRO": "cd %CURRENT%;/bin/bash --login %SSH_ADD_MACRO%",
  "SSH_ADD_MACRO": " -c \"%COMMAND%; /bin/bash\""

  Enterキーで閉じる場合
  "SSH_ADD_MACRO": " -c \"%COMMAND%; echo; read -p 'Press enter key...'\""





※本ソフトウェアで何か起こっても責任はとれません。
  無保証となりますのでご了承ください
